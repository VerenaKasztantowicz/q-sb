# the tests are realized using the "testthat" package
# and can be found in ../inst/tests

require(testthat)
test_check("koRpus")
